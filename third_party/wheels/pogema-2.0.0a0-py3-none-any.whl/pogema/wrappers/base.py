from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gymnasium import Wrapper

if TYPE_CHECKING:
    from pogema.grid import Grid
    from pogema.grid_config import GridConfig

_POGEMA_FORWARDED = frozenset({
    # PogemaBase methods
    'get_num_agents', 'get_obstacles', 'get_agents_xy', 'get_targets_xy',
    'get_state', 'get_agents_xy_relative', 'get_targets_xy_relative',
    'sample_actions',
    # PogemaBase attributes
    'grid_config', 'grid', 'was_on_goal',
    # PogemaLifeLong
    'get_lifelong_targets_xy',
    # AnimationWrapper
    'enable_animation', 'disable_animation', 'save_animation', 'render_animation', 'animation_is_active',
    'save_html_animation', 'render_html_animation', 'save_video_animation', 'save_tikz', 'render_tikz',
})


class PogemaWrapper(Wrapper):
    env: PogemaWrapper

    # -- Gymnasium overrides with multi-agent types --

    def step(self, action) -> tuple[list, list[float], list[bool], list[bool], list[dict]]:
        return self.env.step(action)

    def reset(self, **kwargs) -> tuple[list, list[dict]]:
        return self.env.reset(**kwargs)

    # -- PogemaBase methods --

    def get_num_agents(self) -> int:
        return self.env.get_num_agents()

    def get_obstacles(self, ignore_borders: bool = False) -> np.ndarray:
        return self.env.get_obstacles(ignore_borders=ignore_borders)

    def get_agents_xy(self, only_active: bool = False, ignore_borders: bool = False) -> list:
        return self.env.get_agents_xy(only_active=only_active, ignore_borders=ignore_borders)

    def get_targets_xy(self, only_active: bool = False, ignore_borders: bool = False) -> list:
        return self.env.get_targets_xy(only_active=only_active, ignore_borders=ignore_borders)

    def get_state(self, ignore_borders: bool = False, as_dict: bool = False):
        return self.env.get_state(ignore_borders=ignore_borders, as_dict=as_dict)

    def get_agents_xy_relative(self) -> list:
        return self.env.get_agents_xy_relative()

    def get_targets_xy_relative(self) -> list:
        return self.env.get_targets_xy_relative()

    def sample_actions(self) -> np.ndarray:
        return self.env.sample_actions()

    # -- PogemaBase attributes --

    @property
    def grid_config(self) -> GridConfig:
        return self.unwrapped.grid_config

    @property
    def grid(self) -> Grid:
        return self.unwrapped.grid

    @property
    def was_on_goal(self) -> list:
        return self.unwrapped.was_on_goal

    # -- PogemaLifeLong --

    def get_lifelong_targets_xy(self, ignore_borders: bool = False) -> list:
        return self.env.get_lifelong_targets_xy(ignore_borders=ignore_borders)

    # -- MultiTimeLimit --

    def set_elapsed_steps(self, elapsed_steps: int) -> None:
        return self.env.set_elapsed_steps(elapsed_steps)

    # -- AnimationWrapper --

    def enable_animation(self):
        return self.env.enable_animation()

    def disable_animation(self):
        return self.env.disable_animation()

    def save_animation(self, name='render.svg', **kwargs):
        return self.env.save_animation(name, **kwargs)

    def render_animation(self, **kwargs):
        return self.env.render_animation(**kwargs)

    def save_html_animation(self, name='render.html', **kwargs):
        return self.env.save_html_animation(name, **kwargs)

    def render_html_animation(self, **kwargs):
        return self.env.render_html_animation(**kwargs)

    def save_video_animation(self, name='render.mp4', **kwargs):
        return self.env.save_video_animation(name, **kwargs)

    def save_tikz(self, name='render.tex', **kwargs):
        return self.env.save_tikz(name, **kwargs)

    def render_tikz(self, **kwargs):
        return self.env.render_tikz(**kwargs)

    @property
    def animation_is_active(self):
        return self.env.animation_is_active

    def __repr__(self):
        gc = self.grid_config
        return (
            f"{type(self.unwrapped).__name__}("
            f"num_agents={gc.num_agents}, "
            f"size={gc.width}x{gc.height}, "
            f"on_target='{gc.on_target}', "
            f"collision='{gc.collision_system}')"
        )

    # -- Fallback for any remaining forwarded names --

    def __getattr__(self, name):
        if name in _POGEMA_FORWARDED:
            return getattr(self.env, name)
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
