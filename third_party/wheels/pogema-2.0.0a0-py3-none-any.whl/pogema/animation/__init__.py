"""Internal animation renderers."""
